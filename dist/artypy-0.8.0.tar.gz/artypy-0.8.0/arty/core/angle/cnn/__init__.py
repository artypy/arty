from ._train import model, train
from ._generate import array2angle
