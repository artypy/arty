from . import blur, color
from ._lines import lines
from ._noise import noise
from ._points import points
from ._strokes import strokes
